package com.logging.Logging.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.logging.Logging.DAO.LoginDao;
import com.logging.Logging.Entity.Login;
import com.logging.Logging.Services.LoginServices;
import com.sipios.springsearch.anotation.SearchSpec;


@RestController
public class LoginController {
	
	@Autowired
	private LoginServices service;
	
	@Autowired
	private LoginDao dao;
	
	

	public LoginController(LoginServices service) {
		super();
		this.service = service;
	}

	//list of logging
		@GetMapping("/logging")
		public List<Login> getLogin(){
			return this.service.getLogin();
		}

		
		@PostMapping("/logging")
		public ResponseEntity<HttpStatus>addLogin(@RequestBody Login login){
			try {
					this.service.addLogin(login);
					return new ResponseEntity<>(HttpStatus.OK);
			}catch (Exception e) {
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		
		
		@GetMapping("/logging/{username}")
		public ResponseEntity<HttpStatus>findByUsername(@PathVariable String username){

			try {
					List<Login> dataList= dao.findByUsername(username);
					dataList.forEach(e->{
						System.out.println(e);
					});
					return new ResponseEntity<>(HttpStatus.OK);	
				}catch (Exception e) {
					return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
				}
		}
	
	
}

















