package com.logging.Logging.Services;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.logging.Logging.Entity.Login;

public interface LoginServices {
	
	//public Login addLogin(Login login);
	public List<Login> getLogin();
	public Login addLogin(Login login);
	public Login getLoginById(String id);
	public List<Login> findByUsername(@Param("user") String username);

}
