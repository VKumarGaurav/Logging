package com.logging.Logging.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.logging.Logging.DAO.LoginDao;
import com.logging.Logging.Entity.Login;

@Service
public class LoginServicesImpl implements LoginServices{
	
	@Autowired
	private LoginDao dao;
	
//	List<Login> list= new ArrayList<Login>();
//
//	public LoginServicesImpl() {
//		list.add(new Login(1,"gaurav"));
//	}

	@Override
	public List<Login> getLogin() {
		return this.dao.findAll();
	}

	@Override
	public Login addLogin(Login login) {
		return dao.save(login);
		
	}

	@Override
	public Login getLoginById(String id) {
		return dao.getOne(id);
	}

	@Override
	public List<Login> findByUsername(String username) {
		return this.dao.findByUsername(username);
		
	}

	
	
}











