package com.logging.Logging.DAO;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.logging.Logging.Entity.Login;

public interface LoginDao extends JpaRepository<Login, String>{
	
	@Query("select u from Login as u where u.username = :user")
	public List<Login> findByUsername(@Param("user") String username);

}
